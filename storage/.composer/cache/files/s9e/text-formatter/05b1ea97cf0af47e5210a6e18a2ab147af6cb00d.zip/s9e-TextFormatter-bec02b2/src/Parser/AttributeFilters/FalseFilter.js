const FalseFilter =
{
	/**
	* @param  {*} attrValue
	* @return {boolean}
	*/
	filter: function(attrValue)
	{
		return false;
	}
};