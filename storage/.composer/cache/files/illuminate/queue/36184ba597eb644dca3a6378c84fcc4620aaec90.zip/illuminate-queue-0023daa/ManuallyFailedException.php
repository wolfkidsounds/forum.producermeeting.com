<?php

namespace Illuminate\Queue;

use RuntimeException;

class ManuallyFailedException extends RuntimeException
{
    //
}
