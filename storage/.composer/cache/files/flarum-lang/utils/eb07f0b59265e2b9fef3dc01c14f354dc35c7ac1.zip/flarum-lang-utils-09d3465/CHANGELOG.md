CHANGELOG
=========


1.0.1 (2023-06-13)
------------------

`LanguagePackWithVariants`:

 - Fixed refreshing cache after switching translations variant.


1.0.0 (2023-06-12)
------------------

Initial release with one extender: `LanguagePackWithVariants`.
