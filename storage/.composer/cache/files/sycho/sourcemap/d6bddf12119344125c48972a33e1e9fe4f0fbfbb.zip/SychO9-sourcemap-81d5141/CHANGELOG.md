### dev-master

### 0.1.5 (20.08.2020)

* Find position closest to the requested column (see https://github.com/axypro/sourcemap/pull/6)

### 0.1.4 (16.04.2018)

* https://github.com/axypro/sourcemap/pull/4

### 0.1.3 (30.11.2017)

* Fix https://github.com/axypro/sourcemap/pull/5
* Fix Travis config for PHP 7+

### 0.1.2 (06.01.2017)

* Issue #3: Load `sourcesContent` from file

### 0.1.1 (08.04.2016)

* Issue #1 Serialize parsed mappings
* Travis & Coveralls
* Fix code style

### 0.1.0 (16.03.2015)

* Load/Save source map
* Add/Remove position
* Sources and names
* Search
* Concatenation
* Merge
* Optimization
* Documentation
