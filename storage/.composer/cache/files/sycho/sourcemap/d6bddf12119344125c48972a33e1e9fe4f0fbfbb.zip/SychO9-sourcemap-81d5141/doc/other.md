# Other Methods

## `optimize(void):void`

Optimizes the map structure.
At the moment only removes unused items from `sources` and `names`.
