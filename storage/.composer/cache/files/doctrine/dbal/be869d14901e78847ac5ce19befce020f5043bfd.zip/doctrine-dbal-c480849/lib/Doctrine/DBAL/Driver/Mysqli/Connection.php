<?php

namespace Doctrine\DBAL\Driver\Mysqli;

final class Connection extends MysqliConnection
{
}
