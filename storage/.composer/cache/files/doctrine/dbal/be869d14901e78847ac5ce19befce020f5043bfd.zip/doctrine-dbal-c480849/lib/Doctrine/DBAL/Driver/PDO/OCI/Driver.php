<?php

namespace Doctrine\DBAL\Driver\PDO\OCI;

use Doctrine\DBAL\Driver\PDOOracle;

final class Driver extends PDOOracle\Driver
{
}
