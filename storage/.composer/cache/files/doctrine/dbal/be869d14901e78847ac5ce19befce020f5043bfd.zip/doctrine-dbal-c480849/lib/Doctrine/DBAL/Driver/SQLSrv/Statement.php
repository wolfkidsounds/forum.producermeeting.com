<?php

namespace Doctrine\DBAL\Driver\SQLSrv;

final class Statement extends SQLSrvStatement
{
}
