<?php

declare(strict_types=1);

namespace Laminas\Stratigility\Exception;

/**
 * Marker interface for package-specific exceptions.
 */
interface ExceptionInterface
{
}
