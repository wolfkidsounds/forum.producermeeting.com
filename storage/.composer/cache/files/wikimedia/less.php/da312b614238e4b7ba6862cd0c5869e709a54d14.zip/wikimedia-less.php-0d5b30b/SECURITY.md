# Security policy

Wikimedia takes security seriously. If you believe you have found a
security issue, see <https://www.mediawiki.org/wiki/Reporting_security_bugs>
for information on how to responsibly report it.
