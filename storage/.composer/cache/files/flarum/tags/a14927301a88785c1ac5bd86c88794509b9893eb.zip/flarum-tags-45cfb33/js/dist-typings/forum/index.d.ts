export { default as extend } from './extend';
