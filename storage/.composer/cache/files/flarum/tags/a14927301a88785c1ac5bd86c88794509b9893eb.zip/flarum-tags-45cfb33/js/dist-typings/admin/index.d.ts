export { default as extend } from '../common/extend';
