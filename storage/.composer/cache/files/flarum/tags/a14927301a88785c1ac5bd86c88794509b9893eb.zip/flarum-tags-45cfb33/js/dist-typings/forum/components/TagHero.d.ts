export default class TagHero extends Component<import("flarum/common/Component").ComponentAttrs, undefined> {
    constructor();
    view(): JSX.Element;
}
import Component from "flarum/common/Component";
