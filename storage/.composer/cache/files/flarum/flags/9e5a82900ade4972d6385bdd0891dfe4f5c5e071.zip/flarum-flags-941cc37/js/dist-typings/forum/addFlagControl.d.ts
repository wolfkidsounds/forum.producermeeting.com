export default function _default(): void;
