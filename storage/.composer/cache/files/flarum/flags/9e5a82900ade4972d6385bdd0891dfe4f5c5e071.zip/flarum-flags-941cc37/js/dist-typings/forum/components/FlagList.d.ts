export default class FlagList extends Component<import("flarum/common/Component").ComponentAttrs, undefined> {
    constructor();
    oninit(vnode: any): void;
    state: any;
    view(): JSX.Element;
}
import Component from "flarum/common/Component";
