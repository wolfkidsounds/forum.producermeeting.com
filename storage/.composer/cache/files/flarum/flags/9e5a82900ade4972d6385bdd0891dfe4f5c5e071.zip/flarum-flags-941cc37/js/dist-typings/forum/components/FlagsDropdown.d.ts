export default class FlagsDropdown extends NotificationsDropdown<import("flarum/common/components/Dropdown").IDropdownAttrs> {
    static initAttrs(attrs: any): void;
    constructor();
    getUnreadCount(): any;
    getNewCount(): unknown;
}
import NotificationsDropdown from "flarum/forum/components/NotificationsDropdown";
