import QueueState from './QueueState';
import ControlSectionState from './ControlSectionState';
export default class ExtensionManagerState {
    queue: QueueState;
    control: ControlSectionState;
}
