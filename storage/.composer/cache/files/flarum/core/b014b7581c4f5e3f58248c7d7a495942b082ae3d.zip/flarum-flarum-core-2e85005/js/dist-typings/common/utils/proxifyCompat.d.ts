export default function proxifyCompat(compat: Record<string, unknown>, namespace: string): Record<string, unknown>;
