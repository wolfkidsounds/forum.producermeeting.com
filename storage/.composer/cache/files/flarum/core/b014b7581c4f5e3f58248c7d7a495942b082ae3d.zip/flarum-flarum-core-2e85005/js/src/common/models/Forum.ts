import Model from '../Model';

export default class Forum extends Model {
  apiEndpoint() {
    return '/';
  }
}
