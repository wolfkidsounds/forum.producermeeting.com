import app from './app';
export { app };
export declare const compat: Record<string, unknown>;
