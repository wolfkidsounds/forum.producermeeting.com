export default class ExtensionReadme extends Model {
    content: () => any;
}
import Model from "../../common/Model";
