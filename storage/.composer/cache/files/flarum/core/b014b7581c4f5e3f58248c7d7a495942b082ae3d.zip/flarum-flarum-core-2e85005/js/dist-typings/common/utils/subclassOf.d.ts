/**
 * Check if class A is the same as or a subclass of class B.
 */
export default function subclassOf(A: any, B: any): any;
