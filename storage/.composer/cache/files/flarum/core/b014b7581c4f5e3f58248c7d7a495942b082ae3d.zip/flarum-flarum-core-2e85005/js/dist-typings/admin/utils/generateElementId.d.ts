export { nanoid as default } from 'nanoid';
