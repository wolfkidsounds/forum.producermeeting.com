export default bidi;
declare function bidi(node: any, prop: any): any;
declare namespace bidi {
    function view(ctrl: any, node: any, prop: any): any;
}
