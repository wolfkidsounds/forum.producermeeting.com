import Model from '../../common/Model';

export default class ExtensionReadme extends Model {
  content = Model.attribute('content');
}
