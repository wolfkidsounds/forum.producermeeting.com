/**
 * @see https://stackoverflow.com/a/31732310
 */
export default function isSafariMobile(): boolean;
