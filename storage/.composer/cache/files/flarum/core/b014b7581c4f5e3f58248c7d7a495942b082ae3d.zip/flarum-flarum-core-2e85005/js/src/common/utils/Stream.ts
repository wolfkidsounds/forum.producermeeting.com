import Stream from 'mithril/stream';

export default Stream;
