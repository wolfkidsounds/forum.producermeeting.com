export default class AdminHeader extends Component<import("../../common/Component").ComponentAttrs, undefined> {
    constructor();
    view(vnode: any): JSX.Element[];
}
import Component from "../../common/Component";
