export default function getCategorizedExtensions(): {};
