export default function patchMithril(global: any): void;
