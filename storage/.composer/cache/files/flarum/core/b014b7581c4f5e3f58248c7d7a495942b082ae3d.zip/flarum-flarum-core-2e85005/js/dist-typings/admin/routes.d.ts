import AdminApplication from './AdminApplication';
/**
 * Helper functions to generate URLs to admin pages.
 */
export interface AdminRoutes {
}
/**
 * The `routes` initializer defines the forum app's routes.
 */
export default function (app: AdminApplication): void;
